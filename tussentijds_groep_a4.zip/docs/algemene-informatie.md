# Algemene informatie

## Afspraken

**Werktijden:** 09:15 tot 17:00

**Werkdagen:** maandag tot vrijdag

**Ben je ziek?:** op tijd aangeven, thuis werken en aanwezig zijn op Teams

**Vakanties:** in de vakanties wordt niet gewerkt

**Code:** aan het einde van de dag wordt al het code in de desbetreffende branche gezet

## Team informatie

### Joram Buitenhuis

Persoonlijke kwaliteiten:

1. Graag mensen willen helpen;
2. Gepassioneerd.

Vakkundige kwaliteiten:

1. Veel technische kennis (bv. SQL, Docker, git).

Leerdoelen:

1. Ik wil op tijd beginnen aan mijn persoonlijke verslag;
2. Niet te veel mijn manier van werken op groepsgenoten forceren.

---

### Oktay Soytürk

Persoonlijke kwaliteiten:
1. Perfectionist
2. Goede luisteraar

Vakkundige kwaliteiten:
1. Datamodellen en documentatie maken
2. SQL en Java op gemiddelde niveau

Leerdoelen:
1. Meer betrokken zijn bij gesprekken
2. Vragen stellen wanneer ik iets niet begrijp

---

### Thom Kraaijvanger

Persoonlijke kwaliteiten:
1. Flexibel
2. Stressbestendig

Vakkundige kwaliteiten:
1. Al eerder Spting Boot API gemaakt (Handig indien back-end met java)
2. DMDD Casus met een hoog cijfer afgerond, veel goede voorbeelden voor documentatie

Leerdoelen:
1. Dagelijks logboek bijhouden voor meer overzicht en inzicht
2. Voortouw nemen in goed en regelematig contact met opdrachtgever

---

### Elmar Wiese

Persoonlijke kwaliteiten:
1. Luisteren ik kan.
2. Gemotiveerd

Vakkundige kwaliteiten:
1. SQL
2. Diagram maken

Leerdoelen:
1. Logboek om overzicht te houden wat is gedaan.
2. Presenteren

---

### Tim Meuwsen

Persoonlijke kwaliteitseisen:
1. Gemotiveerd (als het nodig is ben ik bereid lange dagen te maken. (9 tot 5)
2. Sta open voor feedback van teamgenoten.

Vakkundige kwaliteitseisen:
1. Serverside programmeren met java.
2. Niet veel diepgaande kennis maar wel verspreid over verschillende talen.

Leerdoelen:
1. Sneller vragen stellen zodra ik vastloop.
2. Meer gebruik maken van projectrol.

---

### Junjie Juan

Persoonlijke kwaliteiten:
1. Flexibel
2. Hardwerkend

Vakkundige kwaliteiten:
1. SQL
2. Diagram maken

Leerdoelen:
1. Meer zelfonderzoek doen en minder snel vragen om hulp
2. Logboek bijhouden
