db = db.getSiblingDB("flm");

db.createCollection("Test");
