db.Test.insertMany([{
	text: "Dit is een test",
}, {
	text: "Dit is ook een test",
}]);
