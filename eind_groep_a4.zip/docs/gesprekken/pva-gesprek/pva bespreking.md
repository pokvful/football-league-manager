Start. 

 

 

Deelproducten voor school hebbe new weggehaald uit het resultaat. 

Maar het moet wel staan in de projectgrenzen. 

 

Wat bij de resultaat staat moet je benoemen in de deelproducten. 

 

API in de opdracht staat vanuit school en opdrachtgever. 

 

Maak de PvA duidelijk voor de opdrachtgever. (Niet te technisch) 


Onze opdrachtgever is wat technischer dus kan het ook zo in het verslag. 

 

 

Niet goede Doelstellling 

Een database met informatie. (Te specifiek het is een oplossing) 

Wat de opdrachtgever naastreeft is het kunnen voorzien van analystische informatie voor klanten. 

 

Wat wil jij op lange termijn bereiken? = doelstelling. De doelstelling is veel groter dan wij jij hoeft doen. 

 

Een vraag van Thom: Dit lijkt op een doelstelling van een bedrijf.  

Ant: Soort van, Je hebt een doelstelling bij de opdracht  

 

 

Dat klopt. Onze doelstelling  

Opdracht is dit wat de groep moet bereiken. 

 

Dit kunnen wij doen (opdracht) 

Maar daarbij hebben we projectgrenzen en randvoorwaarden. 

 

Inhoudelijke projectgrenzen zijn belangrijk. 

Het kantelpunt benoemen. 

Waar trekken wij de streep. 

Wij doen alleen de back-end en niet een gehele applicatie. 

 

Nieuwe proejctgrens 

KO toernooi wordt wel een gedesignd maar niet geïmplementeerd. 

 

 

Tijdens het project is de process begeileder twee keer per week beschikbaar voor een meeting en is hij contacteerbaar via teams is een randvoorwaarde en geen projectgrens. 

 

 

Randvoorwaarden zijn de Eisen die de opdrachtgever mee eens moet zijn. 

 

Eigen afspreken (H8) is iets van ons. 

 

In afspraken erbij zetten wanneer besprekning. 

Randvoorwaarden opdrachtgever is beschikbaar. 

 

Randvoorwaarden moeten SMART zijn en persoongebonden (niet HAN maar een specifiek persoon) 

 

 

 

Meestal wordt in het achtergrond van het project ook neergezet  

 

De database moet makkelijk uitbreidbaar zijn is niet goed. Het is een gevaarlijke requirement die alleen staat in de achtergrond. 

Dit komt niet terug in het verslag. 

Er moet ergens duidelijk staan hoe, wat makkelijk uitbreidbaar. 

Er zijn nu nog verschillen in perceptie. 

 

In het PvA zetten wat er nu eruit kan worden gehaald en wat nog niet. 

 

Aan Jun. H3 en H6 horen overeen te komen maar de database mist. 

Bij H3 server database bullet weg halen. 

Ze moeten overeenkomen qua benaming. 

 

De linkerkolom gaat over Productkwaliteitseisen (SMART) 

Hoe SMART vind jij de punten? 

 

Het is specifiek in wat erin moet staan. 

Er komt niks over tijdsgebonden in. 

Alleen structurele kwaliteit en niet inhoudelijke. 

 

Concrete Booleans m.b.t het conceptueel datamodel uitleg erbij. 

Het is ook een voorbeeld van goede kwaliteitseis. 

 

Wat aardig is om functie en betekenis in het grotere geheel aan te stippen. 

Waar is het voor en wat maakt het PvA een goede PvA. (Betekenis deelproducten) 

 

De 5xW en 1xH kan strikter bij onze proceskwaliteitseisen. 

Hellaas is het PvA maatwerk. 

 

 

Wie is er verantwoordelijk. Wat moet er gebeuren. Waar in bitbucket. 

 

H7 

Waarschuwing RUP en SCRUM zijn niet hetzelfde! 

Scrummen is kleine projectes achter elkaar. 

 

Bij RUP is in ieder gedeelte andere hoeveelheden van de acties. 

 

 In het begin grootste gedeelte requirements. 

Later andere nadrukken. 

Dit terug te lezen. 

Zoals dat we expirementen gaan doen. 

 

Donderdag is Nils beschikbaar. 

 

Nils docent prof skills. 

Chris procesbegeleider. 

Geen projectbegeleider. 

 

Bij de globale planning een Plaatje. 

Van het globale verloop van RUP. (genchart achtig ding) 

 

 

Risico’s zijn er maar 1. Beetje weinig. 

Er kunnen organistorische en projectmatige risks staan. 

Projectmatig = risk list. 

De toolstack is niet beschikbaar. (Welke ) 

En dit is al afgedekt in de randvoorwaarden. 

 

De risk list. 

Maak je aan het begin. 

Toch er terug in zetten. 

 

Deze risico’s hebben we op deze manier geïntevariseerd. 

En zo hebben we ze getackeled. 

 

 

Is het een problem dat we geen risico’s hebben staan? 

Organisotorisch mag leeg zijn. Maar de bedachte moet wel verwerkt zijn in het PvA. 

Risk list aan het begin van het project wel. 

 

 (pls load)