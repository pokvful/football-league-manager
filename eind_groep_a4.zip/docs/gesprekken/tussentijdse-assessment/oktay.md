# Opmerkingen

## Code

Zet indexen op MSSQL en niet in MongoDB

## CDM

Time bij events nakijken, want het is op het moment niet mogelijk dat
events tegelijkertijd plaatsvinden.

Stad toevoegen is ook meteen een nieuwe voetbalclub toevoegen anders kan
je geen stad toevoegen.

Aantal spelers voor een wedstrijd is minimaal 7, maar hoe ga je dat bij
een wedstrijd checken.

## Ontwerpkeuzes

Waarom kies je voor bij user stories voor bijvoorbeeld triggers of
stored procedures.

## Feittypen

Neem de feittypen erbij en kijk of het overheen komt met de beslissingen
die genomen zijn. De feittypen moeten ook terugkomen in het datamodel en
code.
