---
title: Tussentijdse Assessment
---

Elmar gaat over achtergrond van bedrijf

Thom design descision

Tim rup toelichten

Joram code demonstreren

Oktay en Junjie notulisten

2 events kan nooit tegelijkertijd gebeuren ivm tijd als identifier.
Kijken hoe we dit kunnen oplossen.

Hun kijken naar eind 4 materiaal dan horen we nog niet te weten hoe we
gaan testen maar heb je al een idee. Inzichtelijk maken naar hen is
belangrijk.

Volgende keer als er wordt gevraagd hoe dit is gedaan niet antwoorden
met beetje dit beetje dat.

Wij maken keuzen omeen usecase te maken met sp. Meestal zijn usecases
beperkt. We moeten uitleggen waarom we dit doen. En waarom we een
trigger gebruiken voor usecase. Ze gaan vragen waarom we dit in sp doen
ipv een trigger en dat moeten we kunnen beantwoorden.

We kunnen niet zien wanneer we een Transactions moeten gebruiken

We hadden bedacht dat een club minimaal 11 spelers moet hebben. Is dit
voor een club of is dit in een wedstrijd. Want ze mogen spelen met
minimaal 7 spelers.

We moeten kijken naar performance. Keuzen uitleggen waarom we dit hebben
gedaan dat invloed heeft op performance.

To zit er niet veel ontwerp in.

Ik wil een afgekeurd doelpunt in verwerken, wat kan ik doen als admin om
dit toetevoegen? Kan je dit niet in data verwerken. Kan ik als admin
makkelijk een event toevoegen?

We zijn in onze persoonlijke verslagen heel erg positief, we schrijven
alleen over wat er allemaal is en niet wat er nog niet is.

Hebben we de verwoorden getest op ons conceptueel model???

We moeten beschrijven hoe we een cdm hebben gereviewd waar letten we op
zodat de cdm goed is.

Ze willen weten waar we op moeten letten zodat het onderdeel aan
voldoet.

Voorbeeld zet in definition of done, de cmd voldoet aan de
verwoordingen.

We kunnen wel verantwoorden dit is de feittype die gebruikt worden

Denk na over de kwaliteit!! En leg uit.
