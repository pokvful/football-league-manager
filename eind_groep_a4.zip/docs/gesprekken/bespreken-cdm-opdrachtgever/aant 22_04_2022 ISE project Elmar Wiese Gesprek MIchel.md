Knockout toernooi. Er stond dat het eventueel is.

Idee van hoe het erin kan worden verwerkt.

Vraaier als het erin wordt verwerkt.

Doe dat met 2 versies 1 zonder en 1 met.

En maak de versie met achteraf.

Vragien staging area.

Op welke manier staging area

Iedere nacht data overzetten.

Of constant data oversluizen?

De makkelijkste optie is iets starten in MONGODB wat alle gegevens ophaalt vanuit SQL.

Met een stored procedure alles overzetten.

Mag ook via los python script en niet alllen via de databases zelf

Functie van Stagin area

Stel er zijn veel gebruikers en als die allemaal gegevens gaan opvragen krijgt de database het lasting.

Je kan zoveel staging area’s maken die je wilt. Je ontlast de Database.

Als mensen zelf vragen gaan stellen aan de database.

Kunnen zij intepretatie  verkeerd hebben

Of queries schrijven die zo slecht zijn die de database langzaam wordt.


Met een tussenlaag kun jij zelf de benodige berekeningen uitvoeren voor de data.

Stel dat je de eindgebruikers zelf gegevens laat bewerken zorg je met staging area geen directe toegang.



Dus handig voor voorkouwen data? 

Eens in de zoveel tijd doorsluizen is voor performance goed. Maar zorgt wel voor verschil tussen zichtbare data en echte data.

In ons geval het hoeft niet perfect live. We hebben geen live data.


Hoe komen de mensen bij de data die in Mongo staat.

De gebruikers mogen direct via mongo shell.

Sommige gegevens doen we nu als events en andere als totaal. Is dat prima?

Het is fijner per speler dat ze pases maken.

Dat hoeft weer niet per minuut.

Spelerniveau te zien dat ze pases maken.

Dat met schoten home en schoten uit niet doen.

Andere gekken dingen?

(Alle aangegeven dingen bleken toch niet gek te zijn.)

Kwart voor tien . Vervolg gesprek.

