# ***Disclaimer*** | De lay-out van de PDF-versie voor dit document kan verschillen met de markdown versie, voor een accurate weergave zie markdown bestand in [bitbucket](https://isebitbucket.aimsites.nl/projects/S22122A4/repos/football-league-manager/browse/docs).

# Gesprek met Michel na tussentijdse beoordeling

## Datum 24-05-2022

## Tijd 1:00 t/m 1:15

## Notulist: Tim Meuwsen

- Indexes op Mongo of MSSQL?

Is een goed idee om het transport / create script te optimizen; Hier kunnen we indexes op toepassen.

- Moet het transport script specifieke data doorgeven, wat moet precies in de staging area?
Of is de oplossing die we nu hebben voldoende?

Alleen de views exporteren waar de overzichten op gemaakt kunnen worden.

- Knock-out tournament?

Focus leggen op documentatie, niet op aantal features.
