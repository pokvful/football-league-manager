Situatie: Voortgangsgesprek met Chris over deelproducten.

Datum: 12-05-2022

Tijd: 11:30 – 12:10

Notulist: Tim Meuwsen
      
- Primary key niet in FO maar TO.
- Images fixen in FO (Use case diagram en CDM).
- Images fixen in TO (PDM).
- Procedures toelichten in TO.
- Ontwerpkeuzes toelichten in TO.
- Beschrijving bij rechten matrix moet worden toegevoegd. Is niet duidelijk genoeg wat de - use case precies inhoudt.
- Rechten van users moet specifieker worden geimplementeerd in de database.
- Data-analist moet uit de MSSQL database worden gehaald en in de MongoDB staging area worden geplaatst.
- Non-functional requirements zijn niet SMART genoeg.



