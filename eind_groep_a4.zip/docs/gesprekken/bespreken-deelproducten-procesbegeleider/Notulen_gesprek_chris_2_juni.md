Titel: Gesprek met Chris over voortgang van documentatie
Datum: 2-06-2022
Tijd 9:58 AM -> 11:10 AM
Notulist: Tim Meuwsen

## FO

- Use case model

Secundaire actor mist (staging area), deze plaatsen buiten de box (primaire systeem).
Transport actor in use case model, functie?

NOTE: FUNCTIONEEL HOUDEN

- Verwoordingen

Teveel segmenten in bepaalde zinnen mogen er maar maximaal 2 zijn.
Legenda bij verschillende styling text.

- Business rules

Te technisch, als het gaat om implementatie hoort het niet thuis in het functioneel ontwerp.

BR18 en BR13

- Functionele requirements

Koppeling leggen met use cases. (Kunnen we doen door middel van een extra kolom UC).

Niet-funtionele requirement
De gegevens moeten bereikbaar zijn via een staging area in JSON formaat.

Winter stop functionaliteit in database wordt niet ondersteund. (Doorgeven aan Michel in gesprek).

## TO

Docker verhaal overbodig, niet relevant voor oplevering, wellicht wel handig voor kijk in systeem, of voor toekomstige ontwikkelaars?

Ontwerpkeuzes voor procedures uitbreiden, functioneel gewoon weghalen of herschrijven.

Losse tabellen

Voordeel: Vanuit powerdesigner is het gemakkelijk te genereren.

^ Dit weg

Definition of Done

Tracebility benoemen tussen FO en TO.

## Overig

Eventueel toevoegen van log tabel functionaliteit.
