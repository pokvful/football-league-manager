# ***Disclaimer*** | De lay-out van de PDF-versie voor dit document kan verschillen met de markdown versie, voor een accurate weergave zie markdown bestand in [bitbucket](https://isebitbucket.aimsites.nl/projects/S22122A4/repos/football-league-manager/browse/docs).

# COMPETITIE:

- Naam -
- Seizoen -
- Clubs -
	- (Informatie uit CLUB)
- Standen (op basis van VOETBALWEDSTRIJD)
	- Rang -
	- Club -
	- Gespeeld
	- Winst
	- Gelijk
	- Verlies
	- Doelpunten Voor
	- Doelpunten tegen
	- Doelsaldo
	- Punten
- Toplijsten (op basis van VOETBALWEDSTRIJD)
	- Spelers
		- Topscorers
		- Passes
		- Voorzetten
		- Clean Sheets
		- Rode Kaart
		- Gele Kaart
	- Clubs
		- Goals
		- Passes
		- Clean Sheets
		- Voorzetten
		- Gele Kaarten -
		- Rode Kaarten -
 
# VOETBALWEDSTRIJD:

- Schoten (Aantal Schoten/Aantal Schoten op doel op basis van deze data)
	- Tijdstip
	- Speler
	- Op doel
- Goals (Aantallen weer op basis van deze data)
	- Tijdstip
	- Scorer
- Balbezit (Percentage) -
- Aantal passes -
- Overtredingen (Aantallen weer op basis van deze data) -
	- Speler
	- Tijdstip
- Gele kaarten (Aantallen weer op basis van deze data) -
	- Speler
	- Tijdstip
- Rode kaarten (Aantallen weer op basis van deze data) -
	- Speler
	- Tijdstip
- Buitenspel -
	- Speler
	- Tijdstip
- Hoekschoppen -
	- Speler 
	- Tijdstip
- Wissels (Aantallen weer op basis van deze data)-
	- Speler in
	- Speler uit
	- Tijdstip
 
# MATCHDAY:

- Speelronde -
	- VOETBALWEDSTRIJD -
		- Scheidsrechter
		- Club Thuis -
			- Selectie
		- Club Uit
			- Selectie
		- DateTime
		- Uitslag
		- Aantal toeschouwers
 
# CLUB:

- Thuisstad -
- Stadion -
	- Capaciteit -
- Manager -
- Spelers
	- Rugnummer -
	- Voornaam
	- Achternaam -
	- Geboortedatum -
	- Nationaliteit
	- Positie (Linie)
