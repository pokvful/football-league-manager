set nocount on;
insert into POSITION (Position_type) values ('MIDFIELDER');
insert into POSITION (Position_type) values ('KEEPER');
insert into POSITION (Position_type) values ('DEFENDER');
insert into POSITION (Position_type) values ('ATTACKER');
