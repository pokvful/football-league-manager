set nocount on;
insert into SEASON (Season_name, Season_start, Season_end) values ('20/21', '8/1/2020', '5/31/2021');
insert into SEASON (Season_name, Season_start, Season_end) values ('19/20', '8/1/2019', '5/31/2020');
insert into SEASON (Season_name, Season_start, Season_end) values ('18/19', '8/1/2018', '5/31/2019');
