set nocount on;
insert into COMPETITION_TYPE (Competition_type) values ('Nationale competitie');
insert into COMPETITION_TYPE (Competition_type) values ('Knockout');
