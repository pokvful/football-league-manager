set nocount on;
insert into COMPETITION (Competition_name, Competition_type) values ('Serie A', 'Nationale Competitie');
insert into COMPETITION (Competition_name, Competition_type) values ('Premier League', 'Nationale Competitie');
insert into COMPETITION (Competition_name, Competition_type) values ('La Liga', 'Nationale Competitie');
insert into COMPETITION (Competition_name, Competition_type) values ('Keukenkampioen Divisie', 'Nationale Competitie');
insert into COMPETITION (Competition_name, Competition_type) values ('Eredivisie', 'Nationale Competitie');
insert into COMPETITION (Competition_name, Competition_type) values ('Bundesliga', 'Nationale Competitie');
